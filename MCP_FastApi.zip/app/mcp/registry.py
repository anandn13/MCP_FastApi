from typing import Callable, Dict

class MCPRegistry:
    def __init__(self):
        self.commands: Dict[str, Callable] = {}

    def register(self, name: str):
        def decorator(func: Callable):
            self.commands[name] = func
            return func
        return decorator

    def run(self, name: str, params: dict):
        if name not in self.commands:
            raise ValueError(f"Command '{name}' not found in MCP registry.")
        return self.commands[name](**params)

mcp_registry = MCPRegistry()
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.mcp.registry import mcp_registry
import app.mcp.commands  # Ensures commands are registered

router = APIRouter()

class MCPRequest(BaseModel):
    command: str
    params: dict = {}

@router.post("/run")
def run_mcp_command(request: MCPRequest):
    try:
        result = mcp_registry.run(request.command, request.params)
        return {"result": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
from app.mcp.registry import mcp_registry

@mcp_registry.register("say_hello")
def say_hello(name: str = "World"):
    return f"Hello, {name}!"

@mcp_registry.register("add_numbers")
def add_numbers(a: int, b: int):
    return a + b
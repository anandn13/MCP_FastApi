from fastapi import FastAPI
from app.api.v1 import user
from app.core.config import settings
from app.core.logger import setup_logging
from app.mcp import router as mcp_router

app = FastAPI(title=settings.APP_NAME, debug=settings.DEBUG)
setup_logging(app)

app.include_router(user.router, prefix="/api/v1/users", tags=["users"])
app.include_router(mcp_router.router, prefix="/api/v1/mcp", tags=["mcp"])

@app.get("/")
def root():
    return {"message": f"Welcome to {settings.APP_NAME}!"}
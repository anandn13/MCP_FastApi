import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_create_and_get_user():
    user_data = {
        "username": "testuser",
        "email": "test@example.com",
        "password": "secret"
    }
    # Create user
    response = client.post("/api/v1/users/", json=user_data)
    assert response.status_code == 200
    user = response.json()
    assert user["username"] == user_data["username"]
    assert user["email"] == user_data["email"]

    # Get user
    response = client.get(f"/api/v1/users/{user_data['username']}")
    assert response.status_code == 200
    user = response.json()
    assert user["username"] == user_data["username"]
    assert user["email"] == user_data["email"]